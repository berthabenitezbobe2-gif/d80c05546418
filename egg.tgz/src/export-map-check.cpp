// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("export map check"); }
int main(){
  announce();
  return lionss_run_workload("export-map-check");
}
