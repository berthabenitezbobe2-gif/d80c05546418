// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("allocation bench\n", stdout);
  return lionss_run_workload("allocation-bench");
}
