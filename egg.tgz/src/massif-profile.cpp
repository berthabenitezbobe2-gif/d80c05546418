// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("massif profile\n", stdout);
  return lionss_run_workload("massif-profile");
}
