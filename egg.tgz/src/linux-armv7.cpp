// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux armv7"); }
int main(){
  announce();
  return lionss_run_workload("linux-armv7");
}
