// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("upload artifacts"); }
int main(){
  announce();
  return lionss_run_workload("upload-artifacts");
}
