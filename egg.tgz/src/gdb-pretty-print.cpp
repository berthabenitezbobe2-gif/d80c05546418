// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("gdb pretty print"); }
int main(){
  announce();
  return lionss_run_workload("gdb-pretty-print");
}
