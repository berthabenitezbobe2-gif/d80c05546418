// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("out of tree build"); }
int main(){
  announce();
  return lionss_run_workload("out-of-tree-build");
}
