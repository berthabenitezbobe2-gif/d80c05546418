// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("warm cache bench"); }
int main(){
  announce();
  return lionss_run_workload("warm-cache-bench");
}
