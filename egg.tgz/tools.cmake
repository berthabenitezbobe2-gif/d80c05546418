# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(memory-sanitizer src/memory-sanitizer.cpp)
set_property(TARGET memory-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-sanitizer lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(allocation-bench src/allocation-bench.cpp)
set_property(TARGET allocation-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(allocation-bench lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(iwyu src/iwyu.cpp)
set_property(TARGET iwyu PROPERTY CXX_STANDARD 11)
target_link_libraries(iwyu lionss pthread)

add_executable(windows-arm64 src/windows-arm64.cpp)
set_property(TARGET windows-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(windows-arm64 lionss pthread)

add_executable(concurrency-tests src/concurrency-tests.cpp)
set_property(TARGET concurrency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(concurrency-tests lionss pthread)

add_executable(out-of-tree-build src/out-of-tree-build.cpp)
set_property(TARGET out-of-tree-build PROPERTY CXX_STANDARD 11)
target_link_libraries(out-of-tree-build lionss pthread)

add_executable(massif-profile src/massif-profile.cpp)
set_property(TARGET massif-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(massif-profile lionss pthread)

add_executable(build-no-rtti src/build-no-rtti.cpp)
set_property(TARGET build-no-rtti PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-rtti lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

add_executable(conan-package src/conan-package.cpp)
set_property(TARGET conan-package PROPERTY CXX_STANDARD 11)
target_link_libraries(conan-package lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(raspberry-pi src/raspberry-pi.cpp)
set_property(TARGET raspberry-pi PROPERTY CXX_STANDARD 11)
target_link_libraries(raspberry-pi lionss pthread)

add_executable(clean-rebuild src/clean-rebuild.cpp)
set_property(TARGET clean-rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(clean-rebuild lionss pthread)

add_executable(export-map-check src/export-map-check.cpp)
set_property(TARGET export-map-check PROPERTY CXX_STANDARD 11)
target_link_libraries(export-map-check lionss pthread)

add_executable(split-dwarf src/split-dwarf.cpp)
set_property(TARGET split-dwarf PROPERTY CXX_STANDARD 11)
target_link_libraries(split-dwarf lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(warm-cache-bench src/warm-cache-bench.cpp)
set_property(TARGET warm-cache-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(warm-cache-bench lionss pthread)

add_executable(upgrade-tests src/upgrade-tests.cpp)
set_property(TARGET upgrade-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(upgrade-tests lionss pthread)

add_executable(changelog-render src/changelog-render.cpp)
set_property(TARGET changelog-render PROPERTY CXX_STANDARD 11)
target_link_libraries(changelog-render lionss pthread)

add_executable(coverity-scan src/coverity-scan.cpp)
set_property(TARGET coverity-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(coverity-scan lionss pthread)

add_executable(pitest-run src/pitest-run.cpp)
set_property(TARGET pitest-run PROPERTY CXX_STANDARD 11)
target_link_libraries(pitest-run lionss pthread)

add_executable(ubsan src/ubsan.cpp)
set_property(TARGET ubsan PROPERTY CXX_STANDARD 11)
target_link_libraries(ubsan lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

add_executable(crash-handler-test src/crash-handler-test.cpp)
set_property(TARGET crash-handler-test PROPERTY CXX_STANDARD 11)
target_link_libraries(crash-handler-test lionss pthread)

add_executable(wasm32-build src/wasm32-build.cpp)
set_property(TARGET wasm32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm32-build lionss pthread)

